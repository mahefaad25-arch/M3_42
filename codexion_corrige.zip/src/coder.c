#include "codexion.h"

static long	get_deadline(t_coder *c)
{
	long	last;

	pthread_mutex_lock(&c->deadline_lock);
	last = c->last_compile_start;
	pthread_mutex_unlock(&c->deadline_lock);
	return (last + c->sim->p.time_to_burnout);
}

static void	set_compile_start(t_coder *c, long ts)
{
	pthread_mutex_lock(&c->deadline_lock);
	c->last_compile_start = ts;
	pthread_mutex_unlock(&c->deadline_lock);
}

static int	has_finished(t_coder *c)
{
	int	done;

	pthread_mutex_lock(&c->deadline_lock);
	done = (c->nb_compiles >= c->sim->p.nb_compiles_required);
	pthread_mutex_unlock(&c->deadline_lock);
	return (done);
}

static int	compile_once(t_coder *c)
{
	if (dongle_take_pair(c, get_deadline(c)) == -1)
		return (-1);
	set_compile_start(c, get_timestamp_ms(c->sim));
	log_state(c->sim, c->id, "has taken a dongle");
	log_state(c->sim, c->id, "has taken a dongle");
	log_state(c->sim, c->id, "is compiling");
	ft_usleep_ms(c->sim, c->sim->p.time_to_compile);
	dongle_release(c->sim, c->left_dongle);
	dongle_release(c->sim, c->right_dongle);
	pthread_mutex_lock(&c->deadline_lock);
	c->nb_compiles++;
	pthread_mutex_unlock(&c->deadline_lock);
	return (0);
}

static void	single_coder(t_coder *c)
{
	log_state(c->sim, c->id, "has taken a dongle");
	while (!is_stopped(c->sim))
		usleep(500);
}

void	*coder_routine(void *arg)
{
	t_coder	*c;

	c = (t_coder *)arg;
	if (c->sim->p.nb_coders == 1)
		return (single_coder(c), NULL);
	while (!is_stopped(c->sim) && !has_finished(c))
	{
		if (compile_once(c) == -1)
			break ;
		if (check_all_compiled_enough(c->sim))
		{
			set_stop(c->sim, -1);
			break ;
		}
		log_state(c->sim, c->id, "is debugging");
		ft_usleep_ms(c->sim, c->sim->p.time_to_debug);
		log_state(c->sim, c->id, "is refactoring");
		ft_usleep_ms(c->sim, c->sim->p.time_to_refactor);
	}
	return (NULL);
}
