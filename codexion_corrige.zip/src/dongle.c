#include "codexion.h"

void	dongle_init(t_dongle *d, int id)
{
	d->id = id;
	d->taken = 0;
	d->owner = -1;
	d->free_since_us = -1;
	d->waiters_count = 0;
	pthread_mutex_init(&d->lock, NULL);
}

void	dongle_destroy(t_dongle *d)
{
	pthread_mutex_destroy(&d->lock);
}

static int	is_ready(t_sim *sim, t_dongle *d, int coder_id, long now)
{
	if (d->taken || !is_my_turn(d, coder_id))
		return (0);
	return (d->free_since_us < 0
		|| now - d->free_since_us >= sim->p.dongle_cooldown * 1000);
}

static void	order_pair(t_coder *c, t_dongle **lo, t_dongle **hi)
{
	t_dongle	*l;
	t_dongle	*r;

	l = &c->sim->dongles[c->left_dongle];
	r = &c->sim->dongles[c->right_dongle];
	*lo = l;
	*hi = r;
	if (c->left_dongle > c->right_dongle)
	{
		*lo = r;
		*hi = l;
	}
}

/*
** Premiere demande : ordre de depart deterministe (impairs, puis pairs, puis
** le dernier coder si n est impair, car il est voisin du coder 1). Les valeurs
** sont minuscules (< 3n us), donc toujours avant les demandes suivantes.
*/
static long	start_rank(t_coder *c)
{
	int	n;

	n = c->sim->p.nb_coders;
	if (n % 2 == 1 && c->id == n)
		return (3L * n);
	if (c->id % 2 == 1)
		return (c->id);
	return (n + c->id);
}

/*
** Le coder se met en file sur ses DEUX dongles en meme temps, avec la meme
** arrivee et la meme deadline : l'ordre FIFO/EDF est donc identique sur les
** deux files (ordre total), ce qui evite famine et interblocage.
** Les mutex sont toujours pris dans l'ordre des indices.
*/
static int	enqueue_pair(t_coder *c, t_dongle *lo, t_dongle *hi, long deadline)
{
	t_waiter	w;
	int			ret;

	w.coder_id = c->id;
	w.deadline_ms = deadline;
	pthread_mutex_lock(&lo->lock);
	pthread_mutex_lock(&hi->lock);
	if (c->nb_compiles == 0)
		w.arrival_us = start_rank(c);
	else
		w.arrival_us = get_timestamp_us(c->sim);
	ret = waiter_add(c->sim, lo, &w);
	if (ret == 0 && waiter_add(c->sim, hi, &w) == -1)
	{
		waiter_remove(c->sim, lo, c->id);
		ret = -1;
	}
	pthread_mutex_unlock(&hi->lock);
	pthread_mutex_unlock(&lo->lock);
	return (ret);
}

static int	try_grab(t_coder *c, t_dongle *lo, t_dongle *hi)
{
	long	now;
	int		ok;

	pthread_mutex_lock(&lo->lock);
	pthread_mutex_lock(&hi->lock);
	now = get_timestamp_us(c->sim);
	ok = is_ready(c->sim, lo, c->id, now) && is_ready(c->sim, hi, c->id, now);
	if (ok)
	{
		lo->taken = 1;
		lo->owner = c->id;
		hi->taken = 1;
		hi->owner = c->id;
		waiter_remove(c->sim, lo, c->id);
		waiter_remove(c->sim, hi, c->id);
	}
	pthread_mutex_unlock(&hi->lock);
	pthread_mutex_unlock(&lo->lock);
	return (ok);
}

int	dongle_take_pair(t_coder *c, long deadline)
{
	t_dongle	*lo;
	t_dongle	*hi;

	order_pair(c, &lo, &hi);
	if (enqueue_pair(c, lo, hi, deadline) == -1)
		return (-1);
	while (!is_stopped(c->sim))
	{
		if (try_grab(c, lo, hi))
			return (0);
		usleep(200);
	}
	pthread_mutex_lock(&lo->lock);
	pthread_mutex_lock(&hi->lock);
	waiter_remove(c->sim, lo, c->id);
	waiter_remove(c->sim, hi, c->id);
	pthread_mutex_unlock(&hi->lock);
	pthread_mutex_unlock(&lo->lock);
	return (-1);
}

void	dongle_release(t_sim *sim, int dongle_idx)
{
	t_dongle	*d;

	d = &sim->dongles[dongle_idx];
	pthread_mutex_lock(&d->lock);
	d->taken = 0;
	d->owner = -1;
	d->free_since_us = get_timestamp_us(sim);
	pthread_mutex_unlock(&d->lock);
}
